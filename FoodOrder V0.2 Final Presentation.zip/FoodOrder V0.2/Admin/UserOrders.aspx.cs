﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin_UserOrders : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Email"] != null)
        {
            refreshdata();
        }

       

    }

    public void refreshdata()
    {
        SqlConnection con = new SqlConnection(@"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;");

        SqlCommand cmd = new SqlCommand("select OD.orderId,OD.sno,OD.foodId,OD.foodName,OD.price,OD.quantity,OD.dateForOrder,OC.comments,OC.mobile  from tblOrderDetails as OD join tblOrderComments as OC on  OD.orderId=OC.orderId", con);
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();


    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;");
        string id = (GridView1.DataKeys[e.RowIndex].Values["orderId"].ToString());
        con.Open();
        SqlCommand cmd = new SqlCommand("delete from tblOrderDetails where orderId =@id; delete from tblOrderComments where orderId=@id", con);
        cmd.Parameters.AddWithValue("id", id);
        int i = cmd.ExecuteNonQuery();
        con.Close();
        refreshdata();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("../Home.aspx");

    }
}