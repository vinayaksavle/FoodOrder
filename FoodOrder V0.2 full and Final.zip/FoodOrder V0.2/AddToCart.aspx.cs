﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class AddToCart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Email"] == null)
        {
            Response.Redirect("UserHome.aspx");
        }
        else
        {
            Label1.Text = "Hello " + Session["Email"].ToString();
            LinkButton1.Visible = true;
            lnkLogin.Visible = false;

        }
        if (!IsPostBack)
        {
            DataTable dt = new DataTable();
            DataRow dr;
            dt.Columns.Add("sno");
            dt.Columns.Add("foodId");
            dt.Columns.Add("foodName");
            dt.Columns.Add("quantity");
            dt.Columns.Add("price");
            dt.Columns.Add("totalPrice");
            dt.Columns.Add("foodImage");


            if (Request.QueryString["id"] != null)
            {
                if (Session["Buyitems"] == null)
                {

                    dr = dt.NewRow();
                    SqlConnection scon = new SqlConnection(@"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;");
                    //SqlConnection scon = new SqlConnection(mycon);
                    String myquery = "select * from tblFoodDetails where foodId=" + Request.QueryString["id"];
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = myquery;
                    cmd.Connection = scon;
                    SqlDataAdapter da = new SqlDataAdapter();
                    da.SelectCommand = cmd;
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    dr["sno"] = 1;
                    dr["foodId"] = ds.Tables[0].Rows[0]["foodId"].ToString();
                    dr["foodName"] = ds.Tables[0].Rows[0]["foodName"].ToString();
                    dr["foodImage"] = ds.Tables[0].Rows[0]["foodImage"].ToString();
                    dr["quantity"] = 1;
                    dr["price"] = ds.Tables[0].Rows[0]["price"].ToString();
                    int price = Convert.ToInt16(ds.Tables[0].Rows[0]["price"].ToString());
                    int quantity = Convert.ToInt16(Request.QueryString["quantity"].ToString());
                    int totalprice = price * quantity;
                    dr["totalPrice"] = totalprice;
                    savecartdetail(1, ds.Tables[0].Rows[0]["foodId"].ToString(), ds.Tables[0].Rows[0]["foodName"].ToString(), ds.Tables[0].Rows[0]["foodImage"].ToString(), "1", ds.Tables[0].Rows[0]["price"].ToString(), totalprice.ToString());
                    dt.Rows.Add(dr);
                    GridView1.DataSource = dt;
                    GridView1.DataBind();

                    Session["buyitems"] = dt;
                    GridView1.FooterRow.Cells[5].Text = "Total Amount";
                    GridView1.FooterRow.Cells[6].Text = grandtotal().ToString();
                    Response.Redirect("AddToCart.aspx");

                }
                else
                {

                    dt = (DataTable)Session["buyitems"];
                    int sr;
                    sr = dt.Rows.Count;

                    dr = dt.NewRow();
                    SqlConnection scon = new SqlConnection(@"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;");
                    //SqlConnection scon = new SqlConnection(mycon);
                    String myquery = "select * from tblFoodDetails where foodId=" + Request.QueryString["id"];
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = myquery;
                    cmd.Connection = scon;
                    SqlDataAdapter da = new SqlDataAdapter();
                    da.SelectCommand = cmd;
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    dr["sno"] = sr + 1;
                    dr["foodId"] = ds.Tables[0].Rows[0]["foodId"].ToString();
                    dr["foodName"] = ds.Tables[0].Rows[0]["foodName"].ToString();
                    dr["foodImage"] = ds.Tables[0].Rows[0]["foodImage"].ToString();
                    dr["quantity"] = Request.QueryString["quantity"];
                    dr["price"] = ds.Tables[0].Rows[0]["price"].ToString();
                    int price = Convert.ToInt16(ds.Tables[0].Rows[0]["price"].ToString());
                    int quantity = Convert.ToInt16(Request.QueryString["quantity"].ToString());
                    int totalprice = price * quantity;
                    dr["totalPrice"] = totalprice;
                    savecartdetail(sr + 1, ds.Tables[0].Rows[0]["foodId"].ToString(), ds.Tables[0].Rows[0]["foodName"].ToString(), ds.Tables[0].Rows[0]["foodImage"].ToString(), "1", ds.Tables[0].Rows[0]["price"].ToString(), totalprice.ToString());
                    dt.Rows.Add(dr);
                    GridView1.DataSource = dt;
                    GridView1.DataBind();

                    Session["buyitems"] = dt;
                    GridView1.FooterRow.Cells[5].Text = "Total Amount";
                    GridView1.FooterRow.Cells[6].Text = grandtotal().ToString();
                    Response.Redirect("AddToCart.aspx");

                }
            }
            else
            {
                dt = (DataTable)Session["buyitems"];
                GridView1.DataSource = dt;
                GridView1.DataBind();
                if (GridView1.Rows.Count > 0)
                {
                    GridView1.FooterRow.Cells[5].Text = "Total Amount";
                    GridView1.FooterRow.Cells[6].Text = grandtotal().ToString();

                }


            }
            Label2.Text = GridView1.Rows.Count.ToString();

        }

    }

    public int grandtotal()
    {
        DataTable dt = new DataTable();
        dt = (DataTable)Session["buyitems"];
        int nrow = dt.Rows.Count;
        int i = 0;
        int gtotal = 0;
        while (i < nrow)
        {
            gtotal = gtotal + Convert.ToInt32(dt.Rows[i]["totalPrice"].ToString());

            i = i + 1;
        }
        return gtotal;
    }


    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("UserHome.aspx");
    }

    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        Session["buyitems"] = null;
        clearsavedcart();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("PlaceOrder.aspx");
    }

    private void clearsavedcart()
    {
        SqlConnection con = new SqlConnection(@"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;");

        string updatedata = "delete from tblSavedCartDetail where Email='" + Session["Email"].ToString() + "'";
        //SqlConnection con = new SqlConnection(mycon);
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = updatedata;
        cmd.Connection = con;
        cmd.ExecuteNonQuery();
        Response.Redirect("AddToCart.aspx");
    }

    private void savecartdetail(int sno, String foodId, String foodName, String foodImage, String quantity, String price, String totalPrice)
    {
        string query = "insert into tblSavedCartDetail(sno,foodId,foodName,foodImage,quantity,price,totalPrice,Email) values(" + sno + ",'" + foodId + "','" + foodName + "','" + foodImage + "','" + quantity + "','" + price + "','" + totalPrice + "','" + Session["Email"].ToString() + "')";
        SqlConnection con = new SqlConnection(@"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;");
        //SqlConnection con = new SqlConnection(mycon);
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = query;
        cmd.Connection = con;
        cmd.ExecuteNonQuery();
    }

    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddToCart.aspx");
    }
}