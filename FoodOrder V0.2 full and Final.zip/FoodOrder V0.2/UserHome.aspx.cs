﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class UserHome : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Email"] == null)
        {
            Label1.Text = "Hello Guest,";
            LinkButton2.Visible = true;
            LinkButton1.Visible = false;
        }
        else
        {
            Label1.Text = "Hello " + Session["Email"].ToString();
            LinkButton1.Visible = true;
            LinkButton2.Visible = false;

        }
        DataTable dt = new DataTable();
        dt = (DataTable)Session["buyitems"];
        if (dt != null)
        {

            Label2.Text = dt.Rows.Count.ToString();
        }
        else
        {
            Label2.Text = "0";

        }

    }

    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("Home.aspx");

    }

    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddToCart.aspx");
    }

    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        Response.Redirect("AddToCart.aspx?id=" + e.CommandArgument.ToString() + "&quantity=1");

    }
}