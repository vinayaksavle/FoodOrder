﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class PlaceOrder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataTable dt = new DataTable();
            DataRow dr;
            dt.Columns.Add("sno");
            dt.Columns.Add("foodId");
            dt.Columns.Add("foodName");
            dt.Columns.Add("quantity");
            dt.Columns.Add("price");
            dt.Columns.Add("totalPrice");
            dt.Columns.Add("foodImage");


            if (Request.QueryString["id"] != null)
            {
                if (Session["Buyitems"] == null)
                {

                    dr = dt.NewRow();
                    SqlConnection scon = new SqlConnection(@"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;");
                    //SqlConnection scon = new SqlConnection(mycon);
                    String myquery = "select * from tblFoodDetails where foodId=" + Request.QueryString["id"];
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = myquery;
                    cmd.Connection = scon;
                    SqlDataAdapter da = new SqlDataAdapter();
                    da.SelectCommand = cmd;
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    dr["sno"] = 1;
                    dr["foodId"] = ds.Tables[0].Rows[0]["foodId"].ToString();
                    dr["foodName"] = ds.Tables[0].Rows[0]["foodName"].ToString();
                    dr["foodImage"] = ds.Tables[0].Rows[0]["foodImage"].ToString();
                    dr["quantity"] = 1;
                    dr["price"] = ds.Tables[0].Rows[0]["price"].ToString();
                    int price = Convert.ToInt16(ds.Tables[0].Rows[0]["price"].ToString());
                    int quantity = Convert.ToInt16(Request.QueryString["quantity"].ToString());
                    int totalprice = price * quantity;
                    dr["totalPrice"] = totalprice;
                    //savecartdetail(1, ds.Tables[0].Rows[0]["foodId"].ToString(), ds.Tables[0].Rows[0]["foodName"].ToString(), ds.Tables[0].Rows[0]["foodImage"].ToString(), "1", ds.Tables[0].Rows[0]["price"].ToString(), totalprice.ToString());
                    dt.Rows.Add(dr);
                    GridView1.DataSource = dt;
                    GridView1.DataBind();

                    Session["buyitems"] = dt;
                    GridView1.FooterRow.Cells[5].Text = "Total Amount";
                    GridView1.FooterRow.Cells[6].Text = grandtotal().ToString();
                    Response.Redirect("AddToCart.aspx");


                }
                else
                {
                    dt = (DataTable)Session["buyitems"];
                    int sr;
                    sr = dt.Rows.Count;

                    dr = dt.NewRow();
                    SqlConnection scon = new SqlConnection(@"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;");
                    //SqlConnection scon = new SqlConnection(mycon);
                    String myquery = "select * from tblFoodDetails where foodId=" + Request.QueryString["id"];
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = myquery;
                    cmd.Connection = scon;
                    SqlDataAdapter da = new SqlDataAdapter();
                    da.SelectCommand = cmd;
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    dr["sno"] = sr + 1;
                    dr["foodId"] = ds.Tables[0].Rows[0]["foodId"].ToString();
                    dr["foodName"] = ds.Tables[0].Rows[0]["foodName"].ToString();
                    dr["foodImage"] = ds.Tables[0].Rows[0]["foodImage"].ToString();
                    dr["quantity"] = Request.QueryString["quantity"];
                    dr["price"] = ds.Tables[0].Rows[0]["price"].ToString();
                    int price = Convert.ToInt16(ds.Tables[0].Rows[0]["price"].ToString());
                    int quantity = Convert.ToInt16(Request.QueryString["quantity"].ToString());
                    int totalprice = price * quantity;
                    dr["totalPrice"] = totalprice;

                    dt.Rows.Add(dr);
                    GridView1.DataSource = dt;
                    GridView1.DataBind();

                    Session["buyitems"] = dt;
                    GridView1.FooterRow.Cells[5].Text = "Total Amount";
                    GridView1.FooterRow.Cells[6].Text = grandtotal().ToString();
                    Response.Redirect("AddToCart.aspx");


                }
            }
            else
            {
                dt = (DataTable)Session["buyitems"];
                GridView1.DataSource = dt;
                GridView1.DataBind();
                if (GridView1.Rows.Count > 0)
                {
                    GridView1.FooterRow.Cells[5].Text = "Total Amount";
                    GridView1.FooterRow.Cells[6].Text = grandtotal().ToString();

                }


            }
            // Label2.Text = GridView1.Rows.Count.ToString();

        }
        Label4.Text = DateTime.Now.ToShortDateString();
        findorderid();


    }

    public int grandtotal()
    {
        DataTable dt = new DataTable();
        dt = (DataTable)Session["buyitems"];
        int nrow = dt.Rows.Count;
        int i = 0;
        int gtotal = 0;
        while (i < nrow)
        {
            gtotal = gtotal + Convert.ToInt32(dt.Rows[i]["totalprice"].ToString());

            i = i + 1;
        }
        return gtotal;
    }
    public void findorderid()
    {
        String pass = "abcdefghijklmnopqrstuvwxyz123456789";
        Random r = new Random();
        char[] mypass = new char[5];
        for (int i = 0; i < 5; i++)
        {
            mypass[i] = pass[(int)(35 * r.NextDouble())];

        }
        string orderid;
        orderid = "Order" + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Day.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Year.ToString() + new string(mypass);

        Label3.Text = orderid;


    }

    private void clearsavedcart()
    {
        SqlConnection con = new SqlConnection(@"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;");

        string updatedata = "delete from tblSavedCartDetail where Email='" + Session["Email"].ToString() + "'";
        //SqlConnection con = new SqlConnection(mycon);
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = updatedata;
        cmd.Connection = con;
        cmd.ExecuteNonQuery();
        
    }

    public void saveaddress()
    {
        String updatepass = "insert into tblOrderComments(orderId,comments,mobile) values('" + Label3.Text + "','" + TextBox1.Text + "','" + TextBox2.Text + "')";
        SqlConnection s = new SqlConnection(@"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;");
        //SqlConnection s = new SqlConnection(mycon1);
        s.Open();
        SqlCommand cmd1 = new SqlCommand();
        cmd1.CommandText = updatepass;
        cmd1.Connection = s;
        cmd1.ExecuteNonQuery();
        s.Close();
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        DataTable dt;
        dt = (DataTable)Session["buyitems"];



        for (int i = 0; i <= dt.Rows.Count - 1; i++)
        {
            string updatepass = "insert into tblOrderDetails(orderId,sno,foodId,foodName,price,quantity,dateForOrder) values('" + Label3.Text + "'," + dt.Rows[i]["sno"] + "," + dt.Rows[i]["foodId"] + ",'" + dt.Rows[i]["foodName"] + "'," + dt.Rows[i]["price"] + "," + dt.Rows[i]["quantity"] + ",'" + Label4.Text + "')";
            SqlConnection s = new SqlConnection(@"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;");
            s.Open();
            SqlCommand cmd1 = new SqlCommand();
            cmd1.CommandText = updatepass;
            cmd1.Connection = s;
            cmd1.ExecuteNonQuery();
            s.Close();

        }
        saveaddress();
        Session["buyitems"] = null;
        clearsavedcart();
        Response.Redirect("PlaceSuccessfully.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddToCart.aspx");
    }
}