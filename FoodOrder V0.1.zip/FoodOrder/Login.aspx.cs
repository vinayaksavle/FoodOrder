﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnlogin_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server= LAPTOP-G5IJD7BB\SQLEXPRESS; Database= FoodOrder; Integrated Security=True;");

        lblmsg.Text = "";
        SqlDataAdapter SQLAdapter = new SqlDataAdapter("select * from tblUserLogin where Email='" + txtusername.Text + "' and Password='" + txtpassword.Text + "'", con);
        DataTable DT = new DataTable();
        SQLAdapter.Fill(DT);

        if (DT.Rows.Count > 0)
        {
            lblmsg.Text = "Login Successfully";
            lblmsg.ForeColor = System.Drawing.Color.Green;
            Response.Redirect("UserHome.aspx");
        }

        else
        {
            lblmsg.Text = "Invalid username or password";
            lblmsg.ForeColor = System.Drawing.Color.Red;
        }
    }

}
