﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Admin_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnlogin_Click(object sender, EventArgs e)
    {
        //SqlConnection scon = new SqlConnection(@"Server= LAPTOP-G5IJD7BB\SQLEXPRESS; Database= FoodOrder; Integrated Security=True;");
        SqlConnection scon = new SqlConnection(@"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;");
        
        string myquery = "select * from tblAdminLogin where Email='" + txtusername.Text + "' and Password='" + txtpassword.Text + "'";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = myquery;
        cmd.Connection = scon;
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        DataSet ds = new DataSet();
        da.Fill(ds);
        //string uname;
        //string pass;
        if (ds.Tables[0].Rows.Count > 0)
        {
            string username = ds.Tables[0].Rows[0]["Email"].ToString();
            string password = ds.Tables[0].Rows[0]["Password"].ToString();

            scon.Close();
            if (username == txtusername.Text && password == txtpassword.Text)
            {
                Session["Email"] = username;
                Session["buyitems"] = null;
                
                Response.Redirect("UserHome.aspx");
            }
            else
            {
                lblmsg.Text = "Invalid Username or Password Enter Correct Username Password";
            }
        }
        else
        {
            lblmsg.Text = "Invalid Username or Password Enter Correct Username Password";
        }

    }
}