﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server= LAPTOP-G5IJD7BB\SQLEXPRESS; Database= FoodOrder; Integrated Security=True;");
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into tblUserLogin values(@Name, @Email, @Gender, @Mobile, @Password)", con);
            cmd.Parameters.AddWithValue("Name", txtName.Text);
            cmd.Parameters.AddWithValue("Email", txtEmail.Text);
            cmd.Parameters.AddWithValue("Gender", RadioButtonList1.SelectedValue);
            cmd.Parameters.AddWithValue("Mobile", txtMobile.Text);
            cmd.Parameters.AddWithValue("Password", txtPassword.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            lblMessage.Text = "Registration Successfully";

            if (lblMessage.Text == "Registration Successfully")
            {
                txtName.Text = "";
                txtEmail.Text = "";
                txtEmail.Text = "";
                txtPassword.Text = "";
                txtCPassword.Text = "";
                RadioButtonList1.SelectedValue = "";
            }
        }
    }
}
