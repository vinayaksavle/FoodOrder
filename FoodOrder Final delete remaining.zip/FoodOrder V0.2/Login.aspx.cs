﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnlogin_Click(object sender, EventArgs e)
    {
        //SqlConnection scon = new SqlConnection(@"Server= LAPTOP-G5IJD7BB\SQLEXPRESS; Database= FoodOrder; Integrated Security=True;");
        SqlConnection scon = new SqlConnection(@"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;");
        //SqlConnection scon = new SqlConnection(mycon);
        string myquery = "select * from tblUserLogin where Email='" + txtusername.Text + "' and Password='" + txtpassword.Text + "'";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = myquery;
        cmd.Connection = scon;
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        DataSet ds = new DataSet();
        da.Fill(ds);
        //string uname;
        //string pass;
        if (ds.Tables[0].Rows.Count > 0)
        {
           string username = ds.Tables[0].Rows[0]["Email"].ToString();
           string password = ds.Tables[0].Rows[0]["Password"].ToString();

            scon.Close();
            if (username == txtusername.Text && password == txtpassword.Text)
            {
                Session["Email"] = username;
                Session["buyitems"] = null;
                fillsavedCart();
                Response.Redirect("UserHome.aspx");
            }
            else
            {
                lblmsg.Text = "Invalid Username or Password Enter Correct Username Password";
            }
        }
        else
        {
            lblmsg.Text = "Invalid Username or Password Enter Correct Username Password";
        }





        //////////////////////////////////////////////////




        //SqlConnection con = new SqlConnection(@"Server= LAPTOP-G5IJD7BB\SQLEXPRESS; Database= FoodOrder; Integrated Security=True;");

        //lblmsg.Text = "";
        //SqlDataAdapter SQLAdapter = new SqlDataAdapter("select * from tblUserLogin where Email='" + txtusername.Text + "' and Password='" + txtpassword.Text + "'", con);
        //DataTable DT = new DataTable();
        //SQLAdapter.Fill(DT);

        //if (DT.Rows.Count > 0)
        //{
        //    lblmsg.Text = "Login Successfully";
        //    lblmsg.ForeColor = System.Drawing.Color.Green;
        //    Response.Redirect("UserHome.aspx");
        //}

        //else
        //{
        //    lblmsg.Text = "Invalid username or password";
        //    lblmsg.ForeColor = System.Drawing.Color.Red;
        //}
    }

    private void fillsavedCart()
    {
        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add("sno");
        dt.Columns.Add("foodId");
        dt.Columns.Add("foodName");
        dt.Columns.Add("quantity");
        dt.Columns.Add("price");
        dt.Columns.Add("totalPrice");
        dt.Columns.Add("foodImage");


        //SqlConnection scon = new SqlConnection(mycon);
        SqlConnection scon = new SqlConnection(@"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;");
        //SqlConnection scon = new SqlConnection(@"Server= LAPTOP-G5IJD7BB\SQLEXPRESS; Database= FoodOrder; Integrated Security=True;");
        String myquery = "select * from tblSavedCartDetail where Email='" + Session["Email"].ToString() + "'";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = myquery;
        cmd.Connection = scon;
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            int i = 0;
            int counter = ds.Tables[0].Rows.Count;
            while (i < counter)
            {
                dr = dt.NewRow();
                dr["sno"] = i + 1;
                dr["foodId"] = ds.Tables[0].Rows[i]["foodId"].ToString();
                dr["foodName"] = ds.Tables[0].Rows[i]["foodName"].ToString();
                dr["foodImage"] = ds.Tables[0].Rows[i]["foodImage"].ToString();
                dr["quantity"] = "1";
                dr["price"] = ds.Tables[0].Rows[i]["price"].ToString();
                int price1 = Convert.ToInt16(ds.Tables[0].Rows[i]["price"].ToString());
                int quantity1 = Convert.ToInt16(ds.Tables[0].Rows[i]["quantity"].ToString());
                int totalprice1 = price1 * quantity1;
                dr["totalprice"] = totalprice1;
                dt.Rows.Add(dr);
                i = i + 1;
            }

        }
        else
        {
            Session["buyitems"] = null;
        }
        Session["buyitems"] = dt;
    }


}
