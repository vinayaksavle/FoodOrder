﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin_UserOrders : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection scon = new SqlConnection(@"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;");
        //SqlConnection scon = new SqlConnection(mycon);
//        SELECT Orders.OrderID, Customers.CustomerName, Orders.OrderDate
//FROM Orders
//INNER JOIN Customers ON Orders.CustomerID = Customers.CustomerID;

        SqlDataAdapter sqlDA = new SqlDataAdapter("select * from tblOrderDetails", scon);
        DataTable dtbl = new DataTable();
        sqlDA.Fill(dtbl);
        GridView1.DataSource = dtbl;
        GridView1.DataBind();



    }


    //protected void OnRowDeleting(object sender, GridViewDeleteEventArgs e)
    //{
    //    int orderId = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values[0]);
    //    string query = "DELETE FROM tblOrderDetails WHERE orderId=@orderId";
    //    string constr = @"Server= PC311571\SQLSERVER_2012; Database= FoodOrder; Integrated Security=True;";
    //    using (SqlConnection con = new SqlConnection(constr))
    //    {
    //        using (SqlCommand cmd = new SqlCommand(query))
    //        {
    //            cmd.Parameters.AddWithValue("@orderId", orderId);
    //            cmd.Connection = con;
    //            con.Open();
    //            cmd.ExecuteNonQuery();
    //            con.Close();
    //        }
    //    }

    //    //this.BindGrid();
    //}

    //protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
    //{
    //    if (e.Row.RowType == DataControlRowType.DataRow && e.Row.RowIndex != GridView1.EditIndex)
    //    {
    //        (e.Row.Cells[7].Controls[7] as LinkButton).Attributes["onclick"] = "return confirm('Do you want to delete this row?');";
    //    }
    //}


}